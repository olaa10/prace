 
import math
import numpy as np
import main
import scipy 


def cylinder_area(r:float,h:float):

    if r >= 0 and h >= 0:
        area = 2 * math.pi * r**2 + 2 * math.pi * r * h
        return area
    else:
        return np.NaN
    """Obliczenie pola powierzchni walca. 
    Szczegółowy opis w zadaniu 1.
    
    Parameters:
    r (float): promień podstawy walca 
    h (float): wysokosć walca
    
    Returns:
    float: pole powierzchni walca 
    """

def fib(n: int):
    list_f = np.array([1, 1])
    if isinstance(n, int) and n > 0:
        
        if n == 1:
            return list_f[-2]
        if n == 2:
            return list_f
        else:
            for i in range(3, n + 1):
                list_f = np.append(list_f, [list_f[-1] + list_f[-2]])
            return np.array([list_f])
    else:
        return None

    """Obliczenie pierwszych n wyrazów ciągu Fibonnaciego. 
    Szczegółowy opis w zadaniu 3.
    
    Parameters:
    n (int): liczba określająca ilość wyrazów ciągu do obliczenia 
    
    Returns:
    np.ndarray: wektor n pierwszych wyrazów ciągu Fibonnaciego.
    """
    
def matrix_calculations(a:float):

    Matrix = np.array([[a, 1, -a], [0, 1, 1], [-a, a, 1]])
    Matrix_t = np.transpose(Matrix)
    Matrix_det = np.linalg.det(Matrix) 
    if Matrix_det == 0:
        Matrix_inv = np.NaN 
    else:
        Matrix_inv = np.linalg.inv(Matrix)
    return Matrix_inv, Matrix_t, Matrix_det
    
    """Funkcja zwraca wartości obliczeń na macierzy stworzonej 
    na podstawie parametru a.  
    Szczegółowy opis w zadaniu 4.
    
    Parameters:
    a (float): wartość liczbowa 
    
    Returns:
    touple: krotka zawierająca wyniki obliczeń 
    (Minv, Mt, Mdet) - opis parametrów w zadaniu 4.
    """


def custom_matrix(m:int, n:int):

    """Funkcja zwraca macierz o wymiarze mxn zgodnie 
    z opisem zadania 7.  
    
    Parameters:
    m (int): ilość wierszy macierzy
    n (int): ilość kolumn macierzy  
    
    Returns:
    np.ndarray: macierz zgodna z opisem z zadania 7.
    """
    if (m < 0) or (n < 0):
        return None

    if (type(m) == int) and (type(n) == int):
        Matrix = np.zeros((m, n))
        
        for i in range(m):
            for j in range(n):

                if i > j:
                    Matrix[i][j] = i
                else:
                    Matrix[i][j] = j 

        return Matrix