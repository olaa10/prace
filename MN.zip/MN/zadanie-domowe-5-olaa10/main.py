import numpy as np
import scipy as sp
from scipy import linalg
from  datetime import datetime
import pickle

from typing import Union, List, Tuple


def spare_matrix_Abt(m: int,n: int):
    """Funkcja tworząca zestaw składający się z macierzy A (m,n), wektora b (m,)  i pomocniczego wektora t (m,) zawierających losowe wartości
    Parameters:
    m(int): ilość wierszy macierzy A
    n(int): ilość kolumn macierzy A
    Results:
    (np.ndarray, np.ndarray): macierz o rozmiarze (m,n) i wektorem (m,)
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if all(isinstance(i,int) for i in [m,n]):
        if (m,n > 0):
            t = np.transpose(np.linspace(0, 1, m))
            b = np.cos(4*t)
            A_0 = np.vander(t, n)
            A = np. fliplr(A_0)
            return A,b 
        else:
            return None
    return None