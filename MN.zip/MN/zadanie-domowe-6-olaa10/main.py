import numpy as np
import scipy
import pickle
import matplotlib.pyplot as plt

from typing import Union, List, Tuple

def chebyshev_nodes(n:int=10)-> np.ndarray:
    """Funkcja tworząca wektor zawierający węzły czybyszewa w postaci wektora (n+1,)
    
    Parameters:
    n(int): numer ostaniego węzła Czebyszewa. Wartość musi być większa od 0.
     
    Results:
    np.ndarray: wektor węzłów Czybyszewa o rozmiarze (n+1,). 
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(n, int):
        nodes = np.ndarray(n+1)
        for k in range(n+1):
            nodes[k] = np.cos(k * np.pi / n)
        return nodes

    else:
        return None

def L_inf(xr:Union[int, float, List, np.ndarray],x:Union[int, float, List, np.ndarray])-> float:
    """Obliczenie normy  L nieskończonośćg. 
    Funkcja powinna działać zarówno na wartościach skalarnych, listach jak i wektorach biblioteki numpy.
    
    Parameters:
    xr (Union[int, float, List, np.ndarray]): wartość dokładna w postaci wektora (n,)
    x (Union[int, float, List, np.ndarray]): wartość przybliżona w postaci wektora (n,1)
    
    Returns:
    float: wartość normy L nieskończoność,
                                    NaN w przypadku błędnych danych wejściowych
    """
    if all(isinstance(i, (int, float)) for i in [xr, x]):
        return np.abs(xr - x)

    elif all(isinstance(i, np.ndarray) for i in [xr, x]):
        if xr.shape == x.shape:
            return max(np.abs(xr - x))
        else:
            return np.NaN

    elif all(isinstance(i, list) for i in [xr, x]):
        return np.abs(max(xr) - max(x))

    else:
        return np.NaN


##Z lab_4 
def bar_czeb_weights(n:int=10)-> np.ndarray:
    """Funkcja tworząca wektor wag dla węzłów czybyszewa w postaci (n+1,)
    
    Parameters:
    n(int): numer ostaniej wagi dla węzłów Czebyszewa. Wartość musi być większa od 0.
     
    Results:
    np.ndarray: wektor wag dla węzłów Czybyszewa o rozmiarze (n+1,). 
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(n, int):
        weights = np.ndarray(n+1)
        for j in range(n+1):
            if j == 0 or j == n:
                omega = 0.5
                weights[j] = (-1) ** j * omega

            else:
                omega = 1
                weights[j] = (-1) ** j * omega
        return weights

    else:
        return None