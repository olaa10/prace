import numpy as np
import scipy as sp
from scipy import linalg
from  datetime import datetime
import pickle
import random
from typing import Union, List, Tuple

'''
Do celów testowych dla elementów losowych uzywaj seed = 24122022
'''

def random_matrix_by_egval(egval_vec: np.ndarray):
    """Funkcja z pierwszego zadania domowego
    Parameters:
    egval_vec : wetkor wartości własnych
    Results:
    np.ndarray: losowa macierza o zadanych wartościach własnych 
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(egval_vec, np.ndarray) or all((isinstance(x, int) or isinstance(x, float) or isinstance(x, complex)) for x in egval_vec):
        np.random.seed(24122022)  
        random.seed(24122022)
        n = len(egval_vec)
        J = np.diag(egval_vec)
        P = np.random.rand(n,n)
        return P@J@np.linalg.inv(P)
        
    else:
        return None


def frob_a(coef_vec: np.ndarray):
    """Funkcja z drugiego zadania domowego
    Parameters:
    coef_vec : wetkor wartości wspołczynników
    Results:
    np.ndarray: macierza Frobeniusa o zadanych wartościach współczynników wielomianu 
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(coef_vec, np.ndarray):
        n = len(coef_vec)
        frob_matrix= np.eye(n, n, 1)
        for i in range(n):
            frob_matrix[n - 1][n-1-i] = (-1)*coef_vec[i]
        return frob_matrix

    else:
        return None


    
def polly_from_egval(egval_vec: np.ndarray):
    """Funkcja z laboratorium 8
    Parameters:
    egval_vec: wetkor wartości własnych
    Results:
    np.ndarray: wektor współczynników wielomianu charakterystycznego
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(egval_vec,np.ndarray):
        return np.poly(egval_vec)

    else:
        return None
