import numpy as np
import scipy
import pickle
import math
from typing import Union, List, Tuple


def p_diff(n: int, c: float) -> float:
    """Funkcja wylicza wartości wyrażeń P1 i P2 w zależności od n i c.
    Następnie zwraca wartość bezwzględną z ich różnicy.
    Szczegóły w Zadaniu 2.
    
    Parameters:
    n Union[int]: 
    c Union[int, float]: 
    
    Returns:
    diff float: różnica P1-P2
                NaN w przypadku błędnych danych wejściowych
    """
    if isinstance(n, int) and isinstance(c, (int, float)):
        b = 2 ** n
        P1 = b - b + c
        P2 = b + c - b
        return abs(P1 -P2)
    else:
        return np.NaN
    




def exponential(x: Union[int, float], n: int) -> float:
    """Funkcja znajdująca przybliżenie funkcji exp(x).
    Do obliczania silni można użyć funkcji scipy.math.factorial(x)
    Szczegóły w Zadaniu 3.
    
    Parameters:
    x Union[int, float]: wykładnik funkcji ekspotencjalnej 
    n Union[int]: liczba wyrazów w ciągu
    
    Returns:
    exp_aprox float: aproksymowana wartość funkcji,
                     NaN w przypadku błędnych danych wejściowych
    """
    if isinstance(x, (int, float)) and isinstance(n, int):         
        exp = 0
        if n >= 0:
            for i in range(n):
                exp = exp + (x ** i)/(math.factorial(i)) 
            return exp

        else:
            return np.NaN
    else:
        return np.NaN


def coskx1(k: int, x: Union[int, float]) -> float:
    """Funkcja znajdująca przybliżenie funkcji cos(kx). Metoda 1.
    Szczegóły w Zadaniu 4.
    
    Parameters:
    x Union[int, float]:  
    k Union[int]: 
    
    Returns:
    coskx float: aproksymowana wartość funkcji,
                 NaN w przypadku błędnych danych wejściowych
    """
    if isinstance(x, (int, float)) and isinstance(k, int):
        if k < 0:
            return np.NaN
        if k == 0:
            return 1
        if k == 1:
            return np.cos(x)
        else:
            return 2*np.cos(x) * np.cos((k - 1) * x) - np.cos((k - 2) * x) 
    else:
        return np.NaN

def coskx2(k: int, x: Union[int, float]) -> Tuple[float, float]:
    """Funkcja znajdująca przybliżenie funkcji cos(kx). Metoda 2.
    Szczegóły w Zadaniu 4.
    
    Parameters:
    x Union[int, float]:  
    k Union[int]: 
    
    Returns:
    coskx, sinkx float: aproksymowana wartość funkcji,
                        NaN w przypadku błędnych danych wejściowych
    """
    if isinstance(x, (int, float)) and isinstance(k, int):
        if k < 0:
            return np.NaN
        if k == 0:
            return 1, 0
        if k == 1:
            return np.cos(x), np.sin(x)
        else:
            return np.cos(x) * coskx2(k - 1, x)[0] - np.sin(x) * coskx2(k - 1, x)[1], np.sin(x) * coskx2(k - 1, x)[0] + np.cos(x) * coskx2(k - 1, x)[1] 
    else:
        return np.NaN


####PRACA #### DOMOWA ####

def absolut_error(v: Union[int, float, List, np.ndarray], v_aprox: Union[int, float, List, np.ndarray]) -> Union[int, float, np.ndarray]:
    """Obliczenie błędu bezwzględnego. 
    Funkcja powinna działać zarówno na wartościach skalarnych, listach jak i wektorach/macierzach biblioteki numpy.
    
    Parameters:
    v (Union[int, float, List, np.ndarray]): wartość dokładna 
    v_aprox (Union[int, float, List, np.ndarray]): wartość przybliżona
    
    Returns:
    err Union[int, float, np.ndarray]: wartość błędu bezwzględnego,
                                       NaN w przypadku błędnych danych wejściowych
    """

    if isinstance(v, (int, float, List, np.ndarray)) and isinstance(v_aprox, (int, float, List, np.ndarray)):
        
        if isinstance(v, (int, float)) and isinstance(v_aprox, (int, float)):
            return np.abs(v - v_aprox)



        elif isinstance(v, (int, float)) and isinstance(v_aprox, List):
            abs_list = np.zeros(len(v_aprox), dtype=int)
            for i in range(len(v_aprox)):
                abs_list[i] = np.abs(v-v_aprox[i])
            return abs_list

        elif isinstance(v, List) and isinstance(v_aprox, List):

            if len(v) == len(v_aprox):
                return np.abs(np.array(v) - np.array(v_aprox))
            else:
                return np.NaN

        if isinstance(v, (int, float)) and isinstance(v_aprox, np.ndarray):
            return np.abs(v - v_aprox)   

        if isinstance(v, List) and isinstance(v_aprox, (int,float)):
            abs_list = np.zeros(len(v), dtype=int)

            for i in range(len(v)):
                abs_list[i] = np.abs(v[i] - v_aprox)
            return abs_list

        if isinstance(v, np.ndarray) and isinstance(v_aprox, np.ndarray):
            zip_values = zip(v.shape[::-1], v_aprox.shape[::-1])

            if all((m == n) or (n == 1) or (m == 1) for m,n in zip_values):
                return np.abs(v - v_aprox)
            else:
                return np.NaN



        if isinstance(v, np.ndarray) and isinstance(v_aprox, (int, float)):
            return np.abs(v - v_aprox)

        if isinstance(v, np.ndarray) and isinstance(v_aprox, List):
            if len(v_aprox) == v.shape[0]:
                abs_list = np.zeros(len(v_aprox), dtype=int)
                for i in range(len(v_aprox)):
                    abs_list[i] = np.abs(v[i] - v_aprox[i])
                    return abs_list
            else:
                return np.NaN

        if isinstance(v, List) and isinstance(v_aprox, np.ndarray):
            if len(v) == v_aprox.shape[0]:
                abs_list = np.zeros(len(v), dtype=int)
                for i in range(len(v)):
                    abs_list[i] = np.abs(v[i] - v_aprox[i])
                return abs_list
            else:
                return np.NaN

    else:
        return np.NaN   

def relative_error(v: Union[int, float, List, np.ndarray], v_aprox: Union[int, float, List, np.ndarray]) -> Union[int, float, np.ndarray]:
    """Obliczenie błędu względnego.
    Funkcja powinna działać zarówno na wartościach skalarnych, listach jak i wektorach/macierzach biblioteki numpy.
    
    Parameters:
    v (Union[int, float, List, np.ndarray]): wartość dokładna 
    v_aprox (Union[int, float, List, np.ndarray]): wartość przybliżona
    
    Returns:
    err Union[int, float, np.ndarray]: wartość błędu względnego,
                                       NaN w przypadku błędnych danych wejściowych
    """


    abs_error = absolut_error(v, v_aprox)

    if isinstance(v, np.ndarray) and not v.any():
        return np.NaN

    if isinstance(v, (int, float)) and v == 0:
        return np.NaN

    if abs_error is np.NaN:
        return np.NaN

    if isinstance(v, np.ndarray):
        return np.divide(abs_error,v)

    if isinstance(abs_error, np.ndarray) and isinstance(v, List):
        r_list = np.zeros(len(v))

        for i in range(len(v)):
            if v[i] == 0:
                return np.NaN
            r_list[i] = abs_error[i] / v[i]
        return r_list        
    else:
        return abs_error / v

