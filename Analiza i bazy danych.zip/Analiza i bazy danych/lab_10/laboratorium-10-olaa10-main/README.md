[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/nkC1CPdg)
# Eksploracja danych - część pierwsza.

W ramach dzisiejszego ćwiczenia naszym zadaniem jest opracowanie Data Appendix - dokumentu, który jest przewodnikiem po datasecie.
W ramach tego pliku należy opisać każdą ze zmiennych, określając jej zakresy, podstawowe statystyki, wartości odstające, rozkład (histogram lub wykres słupkowy w zależności od charakteru zmiennej). Należy również wykorzystać metadane w celu opisania jakie zmienna ma jednostki oraz jak należy ją interpretować.

Będziemy pracować na datasecie `beauty.csv`, który pochodzi z badań Hameresh'a i Parker (pdf w repozytorium). Metadane są pod [linkiem](http://www.stat.columbia.edu/~gelman/arm/examples/beauty/ProfEvaltnsBeautyPublic.log). 

Dataset nie jest w postaci tidy (zmienna class jest skonwertowana na 30 zmiennych binarnych) przed analizą należy dokonać przekształcenia. 
