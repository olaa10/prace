library(ggplot2)
# Ćwiczenie 1
wektor <- c(5, 10, 15, 20, 25)
wektor_15 <- wektor[wektor > 15]
srednia <- mean(wektor)
suma <- sum(wektor[1:3])

# Ćwiczenie 2 
wyniki <- c(75, 48, 90, 60, 30)
cat("Wynik egzaminu:", "\n")
for (wynik in wyniki) {
  if (wynik < 60) {
    cat("Niezaliczony", "\n")
  } else {
    cat("Zaliczony", "\n")
  }
}

# Ćwiczenie 3
df <- data.frame(
  Imię = c("Jan", "Ola", "Ela"),
  Wiek = c("25", "30", "28"),
  Punkty = c("85", "92", "78")
)

df$Ocena <- ifelse(df$Punkty >= 91, "bardzo dobry (5.0)",
                   ifelse(df$Punkty >= 81 & df$Punkty <= 90, "plus dobry (4.5)",
                          ifelse(df$Punkty >= 71 & df$Punkty <= 80, "dobry (4.0)",
                                 ifelse(df$Punkty >= 61 & df$Punkty <= 70, "plus dostateczny (3.5)",
                                        ifelse(df$Punkty >= 50 & df$Punkty <= 60, "dostateczny (3.0)",
                                               ifelse(df$Punkty < 50, "niedostateczny (2.0)", ""))))))

osoby_mlodsze <- df[df$Wiek < 30, ]

# Ćwiczenie 4
dane <- data.frame(
  Przedmiot = c("Analiza i Bazy Danych", "Metody numeryczne", "Eksploracja danych"),
  Średnia = c("71", "67", "89"),
  Rocznik = c("2022", "2022", "2022")
)

wykres <- ggplot(dane, aes(x = Przedmiot, y = Średnia)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = "Średni wynik zaliczenia przedmiotów w roku 2022",
       x = "Przedmiot",
       y = "Średnia") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 50, hjust = 1),
        plot.title = element_text(hjust = 0.5))
print(wykres)

# Praca domowa

# Test 1 Wyniki testów Matematyki dla Grupy A i Grupy B
wyniki_grupa_A_t1 <- c(60, 65, 75, 68, 62)
wyniki_grupa_B_t1 <- c(78, 80, 85, 92, 88)
srednia_grupa_A_t1 <- mean(wyniki_grupa_A_t1)

if (srednia_grupa_A_t1 >= 70) {
  dane_do_wykresu_t1 <- data.frame(Grupa = c("A", "B"), Srednia = c(srednia_grupa_A_t1, mean(wyniki_grupa_B_t1)))
  tytul_t1 <- "Średnie wyniki testów Matematyki dla Grupy A i Grupy B (Test 1)"
} else {
  dane_do_wykresu_t1 <- data.frame(Grupa = c("B"), Srednia = mean(wyniki_grupa_B_t1))
  tytul_t1 <- "Średnie wyniki testów Matematyki dla Grupy B (Test 1)"
  cat("Średni wynik Grupy A (Test 1) jest niższy niż 70. Grupa A nie spełnia warunku" , "\n")
}

wykres_t1 <- ggplot(dane_do_wykresu_t1, aes(x = Grupa, y = Srednia)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = tytul_t1, x = "Grupa", y = "Średnia wyników") + 
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))

print(wykres_t1)

# Test 2 Wyniki testów Matematyki dla Grupy A i Grupy B
wyniki_grupa_A_t2 <- c(80, 65, 75, 68, 72)
wyniki_grupa_B_t2 <- c(78, 80, 85, 92, 88)
srednia_grupa_A_t2 <- mean(wyniki_grupa_A_t2)

if (srednia_grupa_A_t2 >= 70) {
  dane_do_wykresu_t2 <- data.frame(Grupa = c("A", "B"), Srednia = c(srednia_grupa_A_t2, mean(wyniki_grupa_B_t2)))
  tytul_t2 <- "Średnie wyniki testów Matematyki dla Grupy A i Grupy B (Test 2)"
} else {
  dane_do_wykresu_t2 <- data.frame(Grupa = c("B"), Srednia = mean(wyniki_grupa_B_t2))
  tytul_t2 <- "Średnie wyniki testów Matematyki dla Grupy B (Test 2)"
  cat("Średni wynik Grupy A (Test 2) jest niższy niż 70. Grupa A nie jest uwzględniona w wykresie.\n")
}

wykres_t2 <- ggplot(dane_do_wykresu_t2, aes(x = Grupa, y = Srednia)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = tytul_t2, x = "Grupa", y = "Średnia wyników") + 
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))

print(wykres_t2)