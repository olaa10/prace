# NIE EDYTOWAĆ *****************************************************************
dsn_database = "wbauer_adb_2023"   # Specify the name of  Database
dsn_hostname = "pgsql-196447.vipserv.org"  # Specify host name 
dsn_port = "5432"                # Specify your port number. 
dsn_uid = "wbauer_adb"         # Specify your username. 
dsn_pwd = "adb2020"        # Specify your password.

library(DBI)
library(RPostgres)
library(testthat)

con <- dbConnect(Postgres(), dbname = dsn_database, host=dsn_hostname, port=dsn_port, user=dsn_uid, password=dsn_pwd) 
# ******************************************************************************
film_in_category <- function(category)
{
  # Funkcja zwracająca wynik zapytania do bazy o tytuł filmu, język, oraz kategorię dla zadanego:
  #     - id: jeżeli categry jest integer
  #     - name: jeżeli category jest character, dokładnie taki jak podana wartość
  # Przykład wynikowej tabeli:
  # |   |title          |languge    |category|
  # |0	|Amadeus Holy	|English	|Action|
  # 
  # Tabela wynikowa ma być posortowana po tylule filmu i języku.
  # 
  # Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  # 
  # Parameters:
  # category (integer,character): wartość kategorii po id (jeżeli typ integer) lub nazwie (jeżeli typ character)  dla którego wykonujemy zapytanie
  # 
  # Returns:
  # DataFrame: DataFrame zawierający wyniki zapytania
  
  if (is.integer(category)) {
    query1 <- sprintf("SELECT f.title, l.name AS languge, c.name AS category 
                      FROM film f
                      JOIN language l ON l.language_id = f.language_id
                      JOIN film_category fc ON fc.film_id = f.film_id
                      JOIN category c ON c.category_id = fc.category_id
                      WHERE c.category_id = %d
                      ORDER BY f.title, languge", category)
  } else if (is.character(category)) {
    query1 <- sprintf("SELECT f.title, l.name AS languge, c.name AS category 
                      FROM film f
                      JOIN language l ON l.language_id = f.language_id
                      JOIN film_category fc ON fc.film_id = f.film_id
                      JOIN category c ON c.category_id = fc.category_id
                      WHERE c.name LIKE '%s'
                      ORDER BY f.title, languge", category)
  } else {
    return(NULL)
  }
  
  result1 <- dbGetQuery(con, query1)
  return(result1)
}

film_in_category_case_insensitive <- function(category)
{
  #  Funkcja zwracająca wynik zapytania do bazy o tytuł filmu, język, oraz kategorię dla zadanego:
  #     - id: jeżeli categry jest integer
  #     - name: jeżeli category jest character
  #  Przykład wynikowej tabeli:
  #     |   |title          |languge    |category|
  #     |0	|Amadeus Holy	|English	|Action|
  #     
  #   Tabela wynikowa ma być posortowana po tylule filmu i języku.
  #     
  #     Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  
  #   Parameters:
  #   category (integer,str): wartość kategorii po id (jeżeli typ integer) lub nazwie (jeżeli typ character)  dla którego wykonujemy zapytanie
  #
  #   Returns:
  #   DataFrame: DataFrame zawierający wyniki zapytania

    if (is.integer(category)) {
    query2 <- sprintf("SELECT f.title, l.name AS languge, c.name AS category
                      FROM film f
                      JOIN language l ON l.language_id = f.language_id
                      JOIN film_category fc ON fc.film_id = f.film_id
                      JOIN category c ON c.category_id = fc.category_id
                      WHERE c.category_id = %d
                      ORDER BY f.title, languge", category)
    } else if (is.character(category)) {
    query2 <- sprintf("SELECT f.title, l.name AS languge, c.name AS category
                      FROM film f
                      JOIN language l ON l.language_id = f.language_id
                      JOIN film_category fc ON fc.film_id = f.film_id
                      JOIN category c ON c.category_id = fc.category_id
                      WHERE LOWER(c.name) LIKE LOWER('%s')
                      ORDER BY f.title, languge", category)
  } else {
    return(NULL)
  }
  
  result2 <- dbGetQuery(con, query2)
  return(result2)
}

film_cast <- function(title)
{
  # Funkcja zwracająca wynik zapytania do bazy o obsadę filmu o dokładnie zadanym tytule.
  # Przykład wynikowej tabeli:
  #     |   |first_name |last_name  |
  #     |0	|Greg       |Chaplin    | 
  #     
  # Tabela wynikowa ma być posortowana po nazwisku i imieniu klienta.
  # Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  # Parameters:
  # title (character): wartość id kategorii dla którego wykonujemy zapytanie
  #     
  # Returns:
  # DataFrame: DataFrame zawierający wyniki zapytania
  
  if (!is.character(title)) {
    return(NULL)
  }  
  query3 <- sprintf("SELECT a.first_name, a.last_name 
                    FROM actor a 
                    JOIN film_actor fa ON fa.actor_id = a.actor_id
                    JOIN film f ON f.film_id = fa.film_id
                    WHERE f.title LIKE '%s'
                    ORDER BY a.last_name, a.first_name", title)
  
  result3 <- dbGetQuery(con, query3)
  return(result3)
}

film_title_case_insensitive <- function(words)
{
  # Funkcja zwracająca wynik zapytania do bazy o tytuły filmów zawierających conajmniej jedno z podanych słów z listy words.
  # Przykład wynikowej tabeli:
  #     |   |title              |
  #     |0	|Crystal Breaking 	| 
  #     
  # Tabela wynikowa ma być posortowana po nazwisku i imieniu klienta.
  # 
  # Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  # Parameters:
  # words(list[character]): wartość minimalnej długości filmu
  #     
  # Returns:
  # DataFrame: DataFrame zawierający wyniki zapytania
  # 
  
  words_str <- paste(words, collapse = '|')
  if (is.character(words)){
  query4 <- sprintf("SELECT title
                     FROM film
                     WHERE title ~* '(?:^| )(%s){1,}(?:$| )'
                     ORDER BY title", words_str)
  }else{
    return(NULL)
  }  
  result4 <- dbGetQuery(con, query4)
  return(result4)
}

# NIE EDYTOWAĆ *****************************************************************
test_dir('tests/testthat')
# ******************************************************************************