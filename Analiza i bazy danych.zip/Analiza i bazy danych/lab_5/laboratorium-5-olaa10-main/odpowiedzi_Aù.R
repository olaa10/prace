#Odpowiedzi
if(!exists("foo", mode="function")) source("main.R")

#Zad.1
#Znajdź wszystkie nazwy krajów rozpoczynających się na P.
query1 <- "SELECT country FROM country WHERE country LIKE 'P%'"

df1 <-dbGetQuery(con,query1)
print(df1)

#Zad.2
#Znajdź wszystkie nazwy krajów rozpoczynających się P i kończących na s.
query2 <- "SELECT country FROM country WHERE country LIKE 'P%%s'"

df2 <-dbGetQuery(con,query2)
print(df2)

#Zad.3
#Znajdź wszystkie tytuły filmów, w których znajdują się cyfry.
query3 <- "SELECT title FROM film WHERE title ~ '\\d'"

df3 <-dbGetQuery(con,query3)
print(df3)

#Zad.4
#Znajdź wszystkich pracowników z podwójnym imieniem lub nazwiskiem.
query4 <- "SELECT first_name, last_name FROM staff WHERE first_name ~ '^[a-zA-Z]+ [a-zA-Z]+$' OR last_name ~ '^[a-zA-Z]+ [a-zA-Z]+$'"

df4 <-dbGetQuery(con,query4)
print(df4)

#Zad.5
#Znajdź wszystkie nazwiska aktorów rozpoczynających się od P lub C i mających 5 znaków.
query5 <- "SELECT last_name FROM actor WHERE (last_name LIKE 'P%' OR last_name LIKE 'C%') AND LENGTH(last_name) = 5"

df5 <-dbGetQuery(con,query5)
print(df5)

#Zad.6
#Znajdź wszystkie tytuły filmów, w których występują słowa Trip lub Alone.
query6 <- "SELECT title FROM film WHERE title ~* 'Trip|Alone'"

df6 <-dbGetQuery(con,query6)
print(df6)

#Zad.7
#Przeanalizuj zapytania:
  #select first_name from actor where first_name ~ '^Al[a:z,1:9]*'
  #select first_name from actor where first_name ~* '^al[a:z,1:9]*'

# Odpowiedź: Powyższe zapytania SQL wydają się próbować znaleźć wszystkie imiona aktorów, które rozpoczynają się od liter 'Al' lub 'al', a następnie mogą zawierać litery od 'a' do 'z' oraz cyfry od 1 do 9.
