library(DBI)
library(RPostgres)

host <- "pgsql-196447.vipserv.org"
port <- "5432"
login <- "wbauer_adb"
hasło <- "adb2020"
nazwa_bazy <- "wbauer_adb_2023"

con <- dbConnect(Postgres(), dbname = nazwa_bazy, host = host, port = port, user = login , password = hasło) 

df1 <- dbGetQuery(con, 'SELECT * FROM category') 
print(df1)
df2 <- dbGetQuery(con, 'SELECT * FROM city') 
print(df2)

#1)Ile kategorii filmów mamy w wypożyczalni?
query1 <- "SELECT COUNT(DISTINCT name) FROM category"
result1 <- dbGetQuery(con, query1)
print(result1)

#2)Wyświetl listę kategorii w kolejności alfabetycznej
query2 <- "SELECT DISTINCT name FROM category ORDER BY name"
result2 <- dbGetQuery(con, query2)
print(result2)

#3)Znajdź najstarszy i najmłodszy film do wypożyczenia
query3_oldest <- "SELECT * FROM film WHERE release_year = (SELECT MIN(release_year) FROM film) ORDER BY title ASC LIMIT 1"
result3_oldest <- dbGetQuery(con, query3_oldest)

query3_youngest <- "SELECT * FROM film WHERE release_year = (SELECT MAX(release_year) FROM film) ORDER BY title DESC LIMIT 1"
result3_youngest <- dbGetQuery(con, query3_youngest)

print("Najstarszy film do wypożyczenia:")
print(result3_oldest)
print("Najmłodszy film do wypożyczenia:")
print(result3_youngest)
#Wszystkie filmy są z tego samego roku, więc jako najmłodszy film przyjęłam pierwszą pozycję z ustawienia alfabetycznego, a jako najstarszy film ostatnią pozycję 

#4)Ile wypożyczeń odbyło się między 2005-07-01 a 2005-08-01?
query4 <- "SELECT COUNT(*) FROM rental WHERE rental_date BETWEEN '2005-07-01' AND '2005-08-01'"
result4 <- dbGetQuery(con, query4)
print("Ilość wypożyczeń między 2005-07-01 a 2005-08-01:")
print(result4)

#5)Ile wypożyczeń odbyło się między 2010-01-01 a 2011-02-01?
query5 <- "SELECT COUNT(return_date) FROM rental WHERE return_date BETWEEN '2010-01-01' AND '2011-02-01'"
result5 <- dbGetQuery(con, query5)
print("Ilość wypożyczeń między 2010-01-01 a 2011-02-01:")
print(result5)

#6)Znajdź największą płatność wypożyczenia
query6 <- "SELECT amount FROM payment WHERE amount = (SELECT MAX(amount) FROM payment) LIMIT 1"
result6 <- dbGetQuery(con, query6)
print(result6)

#7)Znajdź wszystkich klientów z Polski, Nigerii lub Bangladeszu
query7 <- "SELECT customer.first_name, customer.last_name
           FROM customer
           JOIN address ON customer.address_id = address.address_id
           JOIN city ON address.city_id = city.city_id
           JOIN country ON city.country_id = country.country_id
           WHERE country.country IN ('Poland', 'Nigeria', 'Bangladesh')"

result7 <- dbGetQuery(con, query7)
print(result7)

#8)Gdzie mieszkają członkowie personelu?
query8 <- "SELECT staff.first_name, staff.last_name, address.address, city.city, country.country
           FROM staff
           JOIN address ON staff.address_id = address.address_id
           JOIN city ON address.city_id = city.city_id
           JOIN country ON city.country_id = country.country_id"

result8 <- dbGetQuery(con, query8)
print(result8)

#9)Ilu pracowników mieszka w Argentynie lub Hiszpanii?
query9 <- "SELECT COUNT(staff.staff_id)
           FROM staff
           JOIN address ON address.address_id = staff.address_id
           JOIN city ON city.city_id = address.city_id
           JOIN country ON country.country_id = city.country_id
           WHERE country.country IN ('Argentina', 'Spain')"
result9 <- dbGetQuery(con, query9)
print(result9)

#10)Jakie kategorie filmów zostały wypożyczone przez klientów?
query11 <- "SELECT DISTINCT category.name
            FROM category
            JOIN film_category ON category.category_id = film_category.category_id
            JOIN film ON film.film_id = film_category.film_id
            JOIN inventory ON film.film_id = inventory.film_id
            JOIN rental ON inventory.inventory_id = rental.inventory_id
            JOIN customer ON rental.customer_id = customer.customer_id
            JOIN address ON customer.address_id = address.address_id
            JOIN city ON address.city_id = city.city_id
            JOIN country ON city.country_id = country.country_id
            WHERE country.country IN ('United States')"
result11 <- dbGetQuery(con, query11)
print(result11)

#11)Znajdź wszystkie kategorie filmów wypożyczonych w Ameryce
query11 <- "SELECT DISTINCT category.name
            FROM category
            JOIN film_category ON category.category_id = film_category.category_id
            JOIN film ON film.film_id = film_category.film_id
            JOIN inventory ON film.film_id = inventory.film_id
            JOIN rental ON inventory.inventory_id = rental.inventory_id
            JOIN customer ON rental.customer_id = customer.customer_id
            JOIN address ON customer.address_id = address.address_id
            JOIN city ON address.city_id = city.city_id
            JOIN country ON city.country_id = country.country_id
            WHERE country.country IN ('United States')"
result11 <- dbGetQuery(con, query11)
print(result11)

#12)Znajdź wszystkie tytuły filmów, w których grał: Olympia Pfeiffer lub Julia Zellweger lub Ellen Presley
query12 <- "SELECT DISTINCT film.title
           FROM film
           JOIN film_actor ON film.film_id = film_actor.film_id
           JOIN actor ON film_actor.actor_id = actor.actor_id
           WHERE actor.first_name IN ('Olympia', 'Julia', 'Ellen')
           AND actor.last_name IN ('Pfeiffer', 'Zellweger', 'Presley')"

result12 <- dbGetQuery(con, query12)
print(result12)