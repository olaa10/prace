#Odpowiedzi
if(!exists("foo", mode="function")) source("main.R")

#Zad.1
#Znajdź listę wszystkich filmów o tej samej długości.
query1 <- sprintf(" SELECT film.title
                    FROM film
                    WHERE film.length = 60")

df1 <-dbGetQuery(con,query1)
print(df1)

#Zad.2
#Znajdź wszystkich klientów mieszkających w tym samym mieście.
df2 <- client_from_city('London')
print(df2)

#Zad.3 
#Oblicz średni koszt wypożyczenia wszystkich filmów.
query3 <- sprintf(" SELECT AVG(p.amount)
                    FROM film f
                    INNER JOIN inventory i ON f.film_id = i.film_id
                    INNER JOIN rental r ON i.inventory_id = r.inventory_id
                    INNER JOIN payment p ON r.rental_id = p.rental_id")
df3 <- dbGetQuery(con, query3)
print(df3)

#Zad.4
#Oblicz i wyświetl liczbę filmów we wszystkich kategoriach.
query4 <- sprintf(" SELECT COUNT(fc.film_id)
                    FROM category c
                    INNER JOIN film_category fc ON c.category_id = fc.category_id")
df4 <- dbGetQuery(con, query4)
print(df4)

#Zad.5
#Wyświetl liczbę wszystkich klientów pogrupowanych według kraju.
query5 <- sprintf(" SELECT co.country, c.first_name, c.last_name
                    FROM customer c
                    INNER JOIN address a ON c.address_id = a.address_id
                    INNER JOIN city ci ON a.city_id = ci.city_id
                    INNER JOIN country co ON ci.country_id = co.country_id
                    ORDER BY co.country, c.last_name, c.first_name")
df5 <- dbGetQuery(con, query5)
print(df5)

#Zad.6
#Wyświetl informacje o sklepie, który ma więcej niż 100 klientów i mniej niż 300 klientów.
query6 <- sprintf(" SELECT s.store_id, s.manager_staff_id, COUNT(DISTINCT c.customer_id)
                    FROM store s
                    INNER JOIN staff st ON s.store_id = st.store_id
                    INNER JOIN rental r ON st.staff_id = r.staff_id
                    INNER JOIN customer c ON c.customer_id = r.customer_id
                    GROUP BY s.store_id
                    HAVING COUNT(DISTINCT c.customer_id) BETWEEN 100 AND 300")
df6 <- dbGetQuery(con, query6)
print(df6)

#Zad.7
#Wybierz wszystkich klientów, którzy oglądali filmy ponad 200 godzin.
df7 <- client_by_sum_length(200)
print(df7)

#Zad.8
#Oblicz średnią wartość wypożyczenia filmu.
query8 <- sprintf(" SELECT AVG(p.amount)
                    FROM payment p")
df8 <- dbGetQuery(con, query8)
print(df8)

#Zad.9
#Oblicz średnią wartość długości filmu we wszystkich kategoriach.
query9 <- sprintf(" SELECT AVG(f.length)
                    FROM category c
                    INNER JOIN film_category fc ON c.category_id = fc.category_id
                    INNER JOIN film f ON fc.film_id = f.film_id")
df9 <- dbGetQuery(con, query9)
print(df9)

#Zad.10
#Znajdź najdłuższe tytuły filmowe we wszystkich kategoriach.
query10 <- sprintf( "SELECT c.name, f.title, f.length
                    FROM film f
                    INNER JOIN film_category fc ON fc.film_id = f.film_id
                    INNER JOIN category c ON fc.category_id = c.category_id
                    WHERE f.length = (SELECT MAX(length) FROM film)")
df10 <- dbGetQuery(con, query10)
print(df10)

#Zad.11
#Znajdź najdłuższe tytuły filmowe we wszystkich kategoriach.
query10 <- sprintf( "SELECT c.name, f.title, f.length
                    FROM film f
                    INNER JOIN film_category fc ON fc.film_id = f.film_id
                    INNER JOIN category c ON fc.category_id = c.category_id
                    WHERE f.length = (SELECT MAX(length) FROM film)")
df10 <- dbGetQuery(con, query10)
print(df10)