# NIE EDYTOWAĆ *****************************************************************
dsn_database = "wbauer_adb_2023"   # Specify the name of  Database
dsn_hostname = "pgsql-196447.vipserv.org"  # Specify host name 
dsn_port = "5432"                # Specify your port number. 
dsn_uid = "wbauer_adb"         # Specify your username. 
dsn_pwd = "adb2020"        # Specify your password.

library(DBI)
library(RPostgres)
library(testthat)

con <- dbConnect(Postgres(), dbname = dsn_database, host=dsn_hostname, port=dsn_port, user=dsn_uid, password=dsn_pwd) 
# ******************************************************************************

film_in_category<- function(category_id)
{
  # Funkcja zwracająca wynik zapytania do bazy o tytuł filmu, język, oraz kategorię dla zadanego id kategorii.
  # Przykład wynikowej tabeli:
  # |   |title          |language    |category|
  # |0	|Amadeus Holy	|English	|Action|
  # 
  # Tabela wynikowa ma być posortowana po tytule filmu i języku.
  # 
  # Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL
  # 
  # Parameters:
  # category_id (integer): wartość id kategorii dla którego wykonujemy zapytanie
  # 
  # Returns:
  # DataFrame: DataFrame zawierający wyniki zapytania
  # 
  
  if (!is.integer(category_id)) {
    return(NULL)
  }
  query1 <- sprintf("SELECT film.title, language.name AS language, fl.category 
                    FROM film
                    JOIN film_list fl ON fl.fid = film.film_id
                    JOIN film_category fc ON fc.film_id = film.film_id
                    JOIN language ON language.language_id = film.language_id
                    WHERE fc.category_id = %d
                    ORDER BY title", category_id)
  
  result1 <- dbGetQuery(con, query1)
  return(result1)
}


number_films_in_category <- function(category_id){
  #   Funkcja zwracająca wynik zapytania do bazy o ilość filmów w zadanej kategori przez id kategorii.
  #     Przykład wynikowej tabeli:
  #     |   |category   |count|
  #     |0	|Action 	|64	  | 
  #     
  #     Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  #     Parameters:
  #     category_id (integer): wartość id kategorii dla którego wykonujemy zapytanie
  #     
  #     Returns:
  #     DataFrame: DataFrame zawierający wyniki zapytania

  if (!is.integer(category_id)) {
    return(NULL)
  }
  
  query2 <- sprintf("SELECT c.name AS category, COUNT(f.film_id) AS count
                    FROM film_category fc
                    JOIN category c ON fc.category_id = c.category_id
                    JOIN film f ON fc.film_id = f.film_id
                    WHERE c.category_id = %d
                    GROUP BY c.name", category_id)
  
  result2 <- dbGetQuery(con, query2)
  return(result2)
}



number_film_by_length <- function(min_length, max_length){
  #   Funkcja zwracająca wynik zapytania do bazy o ilość filmów dla poszczególnych długości pomiędzy wartościami min_length a max_length.
  #     Przykład wynikowej tabeli:
  #     |   |length     |count|
  #     |0	|46 	    |64	  | 
  #     
  #     Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  #     Parameters:
  #     min_length (int,double): wartość minimalnej długości filmu
  #     max_length (int,double): wartość maksymalnej długości filmu
  #     
  #     Returns:
  #     pd.DataFrame: DataFrame zawierający wyniki zapytania
  if (!is.numeric(min_length) || !is.numeric(max_length)) {
    return(NULL)
  }
  
  if (min_length > max_length) {
    return(NULL)
  }
  
  query3 <- sprintf("SELECT length, COUNT(title) AS count
                    FROM film
                    WHERE length BETWEEN %f AND %f
                    GROUP BY length", min_length, max_length)
  
  result3 <- dbGetQuery(con, query3)
  return(result3)
}



client_from_city<- function(city){
  #   Funkcja zwracająca wynik zapytania do bazy o listę klientów z zadanego miasta przez wartość city.
  #     Przykład wynikowej tabeli:
  #     |   |city	    |first_name	|last_name
  #     |0	|Athenai	|Linda	    |Williams
  #     
  #     Tabela wynikowa ma być posortowana po nazwisku i imieniu klienta.
  #     
  #     Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  #     Parameters:
  #     city (character): nazwa miaste dla którego mamy sporządzić listę klientów
  #     
  #     Returns:
  #     DataFrame: DataFrame zawierający wyniki zapytania
  
  if (!is.character(city)) {
    return(NULL)
  }
  query4 <- sprintf("SELECT city.city, c.first_name, c.last_name
                    FROM city
                    JOIN address ON address.city_id = city.city_id
                    JOIN customer c ON c.address_id = address.address_id
                    WHERE city.city = '%s'
                    ORDER BY last_name, first_name", city)
  
  result4 <- dbGetQuery(con, query4)
  return(result4)
}


avg_amount_by_length<-function(length){
  #   Funkcja zwracająca wynik zapytania do bazy o średnią wartość wypożyczenia filmów dla zadanej długości length.
  #     Przykład wynikowej tabeli:
  #     |   |length |avg
  #     |0	|48	    |4.295389
  #     
  #     
  #     Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  #     Parameters:
  #     length (integer,double): długość filmu dla którego mamy pożyczyć średnią wartość wypożyczonych filmów
  #     
  #     Returns:
  #     DataFrame: DataFrame zawierający wyniki zapytania
  
  if (!is.numeric(length)) {
    return(NULL)
  }
  
  query5 <- sprintf("SELECT film.length, AVG(payment.amount) AS avg
                    FROM film
                    JOIN inventory i ON i.film_id = film.film_id
                    JOIN rental r ON r.inventory_id = i.inventory_id
                    JOIN payment ON payment.rental_id = r.rental_id
                    WHERE film.length = %f
                    GROUP BY film.length", length)
  
  result5 <- dbGetQuery(con, query5)
  return(result5)
}


client_by_sum_length<-function(sum_min){
  #   Funkcja zwracająca wynik zapytania do bazy o sumaryczny czas wypożyczonych filmów przez klientów powyżej zadanej wartości .
  #     Przykład wynikowej tabeli:
  #     |   |first_name |last_name  |sum
  #     |0  |Brian	    |Wyman  	|1265
  #     
  #     Tabela wynikowa powinna być posortowane według sumy, imienia i nazwiska klienta.
  #     Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  #     Parameters:
  #     sum_min (integer,double): minimalna wartość sumy długości wypożyczonych filmów którą musi spełniać klient
  #     
  #     Returns:
  #     DataFrame: DataFrame zawierający wyniki zapytania
  if (!is.numeric(sum_min) || sum_min < 0) {
    return(NULL)
  }
  
  query6 <- sprintf("SELECT c.first_name, c.last_name, SUM(f.length) AS sum
                    FROM film AS f
                    JOIN inventory AS i ON i.film_id = f.film_id
                    JOIN rental AS r ON r.inventory_id = i.inventory_id
                    JOIN customer AS c ON c.customer_id = r.customer_id
                    GROUP BY c.first_name, c.last_name
                    HAVING SUM(f.length) > %f
                    ORDER BY sum, c.last_name, c.first_name", sum_min)
  
  result6 <- dbGetQuery(con, query6)
  return(result6)
}

category_statistic_length<-function(name){
  #   Funkcja zwracająca wynik zapytania do bazy o statystykę długości filmów w kategorii o zadanej nazwie.
  #     Przykład wynikowej tabeli:
  #     |   |category   |avg    |sum    |min    |max
  #     |0	|Action 	|111.60 |7143   |47 	|185
  #     
  #     Jeżeli warunki wejściowe nie są spełnione to funkcja powinna zwracać wartość NULL.
  #         
  #     Parameters:
  #     name (character): Nazwa kategorii dla której ma zostać wypisana statystyka
  #     
  #     Returns:
  #     DataFrame: DataFrame zawierający wyniki zapytania
  if (!is.character(name)) {
    return(NULL)
  }
  
  query7 <- sprintf("SELECT c.name AS category, AVG(f.length) AS avg, SUM(f.length) AS sum, MIN(f.length) AS min, MAX(f.length) AS max
                    FROM film AS f
                    JOIN film_category AS fc ON fc.film_id = f.film_id
                    JOIN category AS c ON c.category_id = fc.category_id
                    WHERE c.name = '%s'
                    GROUP BY c.name", name)
  
  result7 <- dbGetQuery(con, query7)
  return(result7)
}

# NIE EDYTOWAĆ *****************************************************************
test_dir('tests/testthat')
# ******************************************************************************