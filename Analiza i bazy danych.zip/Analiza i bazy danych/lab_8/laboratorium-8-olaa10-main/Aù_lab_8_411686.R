### Geomy i estetyki
## Wykresy punktowe (scatterplot)

library(tidyverse)
patients <- read_tsv("patient-data-cleaned.txt")

#1) Narysuj wykres punktowy wagi pacjenta w funkcji BMI i pokoloruj punkty w oparciu o wzrost.

ggplot(patients, aes(x = BMI, y = Weight, color = Height)) +
  geom_point() +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Weight") +
  scale_colour_gradient2(low = "blue", mid = "white", high = "red", midpoint = median(patients$Height)) +
  theme_minimal()

#2) Za pomocą dodatkowego geoma dopasuj gładką linię określającą trend.

ggplot(patients, aes(x = BMI, y = Weight, color = Height, group = Height)) +
  geom_point() +
  geom_smooth(method = "loess", se = FALSE) + 
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI z trendem",
       x = "BMI",
       y = "Weight") +
  scale_colour_gradient2(low = "blue", mid = "white", high = "red", midpoint = median(patients$Height)) +
  theme_minimal()

#3) Dostosuj metodę tak, aby pasowała do linii prostej i nie rysowała przedziału ufności.

ggplot(patients, aes(x = BMI, y = Weight, color = Height, group = Height)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +  
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI z dostosowanym trendem",
       x = "BMI",
       y = "Weight") +
  scale_colour_gradient2(low = "blue", mid = "white", high = "red", midpoint = median(patients$Height)) +
  theme_minimal()

#Odp. Dopasowanie z poprzedniego wykresu trochę odbiega od tego 

## Wykresy pudełkowe
#1) Wygeneruj wykres pudełkowy zmiennej Score porównując palaczy i niepalących.

ggplot(patients, aes(x = Smokes, y = Score, fill = Smokes)) +
  geom_boxplot() +
  labs(title = "Wykres pudełkowy porównujący palaczy i niepalących",
       x = "Palenie",
       y = "Wynik") +
  theme_minimal()

#2) Za pomocą kolorów rozdziel wykresy pudełkowe dodatkowo ze względu na płeć.

ggplot(patients, aes(x = Smokes, y = Score, fill = Sex, color = Sex)) +
  geom_boxplot(position = position_dodge(width = 0.8), alpha = 0.7) +
  labs(title = "Wykres pudełkowy porównujący palaczy i niepalących z podziałem na płeć",
       x = "Palenie",
       y = "Wynik") +
  theme_minimal()

##Histogramy i estymatory jądrowe
#1) Wygeneruj histogram BMI kolorując każdy słupek na niebiesko. Dobierz odpowiednią szerokość przedziałów (binów). Swój wybór uzasadnij.

ggplot(patients, aes(x = BMI)) +
  geom_histogram(binwidth = 2, fill = "blue", color = "white", alpha = 0.7) +
  labs(title = "Histogram BMI",
       x = "BMI",
       y = "Liczba pacjentów") +
  theme_minimal()

#Odp. Zdecydowałam się na szerokość przedziałów (binów) równą 2, ponieważ przy takiej wartości można wystarczająco zobaczyć ogólny rozkład danych i zidentyfikować, w których obszarach skupiają się wartości BMI. Szerokość 2 jednostek jest również wystarczającoc duża, aby zachować czytelność i estetykę wykresu. W kontekście BMI, szereokość ta jest na tyle mała, że umożliwia identyfikację różnic, które mogą być praktyczne z punktu widzenia masy ciała.

#2) Zamiast histogramu wygeneruj wykres estymatora jądrowego.

ggplot(patients, aes(x = BMI, fill = Sex)) +
  geom_density(alpha = 0.5) +
  labs(title = "Estymator jądrowy BMI",
       x = "BMI",
       y = "Gęstość") +
  theme_minimal()

#3)Porównaj histogram z estymatorem jądrowym na jednym wykresie. Ustaw przeźroczystość histogramu (alpha) na 20%. Dlaczego wysokości wykresów są różne? Ustaw estetykę globalną wykresu tak, aby ujednolicić pionową oś (wskazówka: użyj funkcji after_stat() z odpowiednim argumentem)

ggplot(patients, aes(x = BMI, fill = Sex)) +
  geom_histogram(binwidth = 2, color = "white", alpha = 0.2, position = "identity") +
  geom_density(alpha = 0.5, color = "blue") +
  labs(title = "Porównanie histogramu z estymatorem jądrowym BMI",
       x = "BMI",
       y = "Liczba pacjentów / Gęstość") +
  theme_minimal() +
  scale_y_continuous(labels = function(x) ifelse(is.na(x), 0, x),
                     breaks = c(0, 5, 10, 15, 20))  # Ujednolicenie pionowej osi

#Odp. Wysokości wykresów są różne, ponieważ histogram przedstawia liczbę obserwacji, a estymator jądrowy prezentuje gęstość prawdopodobieństwa, co może skutkować różnicami w skali między nimi.

#4) Wygeneruj wykresy estymatorów jądrowych BMI pokolorowane ze względu na płeć (kolor wypełnienia). Dobierz odpowiednią przeźroczystość.

ggplot(patients, aes(x = BMI, fill = Sex)) +
  geom_density(alpha = 0.5) +
  labs(title = "Estymator jądrowy BMI ze względu na płeć",
       x = "BMI",
       y = "Gęstość") +
  theme_minimal()

## Kafelki
#1) Narysuj wykres punktowy wagi pacjenta w funkcji BMI i pokoloruj punkty w oparciu o wzrost. Podziel go na siatkę wykresów (kafelki) w oparciu o płeć i palenie papierosów.

ggplot(patients, aes(x = BMI, y = Weight, color = Height)) +
  geom_point() +
  facet_grid(Sex ~ Smokes, scales = "free") +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Weight") +
  theme_minimal()

#2)Wygeneruj wykres pudełkowy BMI porównując palących i niepalących, pokolorowanych ze względu na płeć i dodaj osobny kafelek ze względu na wiek.

ggplot(patients, aes(x = factor(Smokes), y = BMI, fill = factor(Sex))) +
  geom_boxplot() +
  facet_grid(Age ~ ., scales = "free_y") +
  labs(title = "Wykres pudełkowy BMI porównujący palących i niepalących",
       x = "Palenie",
       y = "BMI") +
  scale_fill_manual(values = c("blue", "pink")) +  # Dostosuj kolory do płci
  theme_minimal()

#3) Utwórz podobny boxplot BMI, ale tym razem pogrupuj dane ze względu na płeć, pokoloruj ze względu na wiek (wskazówka:przekształć kolor do zmiennej kategorycznej) a kafelki ze względu na to kto jest osobą palącą.

ggplot(patients, aes(x = Sex, y = BMI, fill = factor(Age), color = factor(Smokes))) +
  geom_boxplot() +
  facet_grid(Smokes ~ ., scales = "free_y") +
  labs(title = "Boxplot BMI według płci, wieku i palenia",
       x = "Płeć",
       y = "BMI") +
  scale_fill_manual(values = c("blue", "pink", "green")) + 
  scale_color_manual(values = c("red", "blue")) +  
  theme_minimal()

### Skale i tematy
## Skale
#1) Narysuj wykres punktowy wagi pacjenta w funkcji BMI.

ggplot(patients, aes(x = BMI, y = Weight)) +
  geom_point() +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Weight") +
  theme_minimal()

#2) Zaczynając od poprzedniego wykresu dostosuj oś BMI tak aby zaznaczone byly tylko wartości 20, 30, 40 a na osi wagi wartości od 60 do 100 ze skokiem 5. Dodaj polską nazwę zmiennej i jednostkę (kg).

ggplot(patients, aes(x = BMI, y = Weight)) +
  geom_point() +
  scale_x_continuous(breaks = c(20, 30, 40)) +
  scale_y_continuous(breaks = seq(60, 100, by = 5)) +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Waga (kg)") +
  theme_minimal()

#3) Narysuj wykres punktowy wagi pacjenta w funkcji BMI. Pokoloruj go w skali kolorowej ze względu na wzrost. Utwórz skalę kolorystyczną z punktem środkowym odpowiadającym średniemu wzrostowi pacjenta zaś ekstremami skali mają być zielony (minimum) i czerwony (maksimum) w odcieniach zgodnych z kolorami AGH. Jako środkowy kolor przyjąć szarość grey

colors <- c("darkgreen", "grey", "darkred")

ggplot(patients, aes(x = BMI, y = Weight, color = Height)) +
  geom_point() +
  scale_color_gradientn(colors = colors, values = scales::rescale(c(min(patients$Height), mean(patients$Height), max(patients$Height)))) +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Waga") +
  theme_minimal()

## Motywy
#1) Narysuj wykres punktowy wagi pacjenta w funkcji BMI. Pokoloruj go w skali kolorowej ze względu na wzrost. Dodaj do niego linie trendu bez przedziałów ufności dla każdej z grup wiekowych

ggplot(patients, aes(x = BMI, y = Weight, color = Height, group = factor(Age))) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, aes(group = factor(Age)), color = "black") +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Waga") +
  scale_colour_gradient2(low = "blue", mid = "white", high = "red", midpoint = median(patients$Height)) +
  theme_minimal()

#2) Usuń tytuł legendy. Zmień kolory tła pozycji legendy (key) na biało i umieść legendę pod wykresem.

ggplot(patients, aes(x = BMI, y = Weight, color = Height, group = factor(Age))) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, aes(group = factor(Age)), color = "black") +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Waga") +
  scale_colour_gradient2(low = "blue", mid = "white", high = "red", midpoint = median(patients$Height)) +
  theme_minimal() +
  theme(legend.position = "bottom", legend.background = element_rect(fill = "white"))

#3) Dodaj odpowiedni tytuł do wykresu. Usuń pomniejsze linie siatki. Zapisz jako plik png o wymiarach 16 na 16 cm.

ggplot(patients, aes(x = BMI, y = Weight, color = Height, group = factor(Age))) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE, aes(group = factor(Age)), color = "black") +
  labs(title = "Wykres punktowy wagi pacjenta w funkcji BMI",
       x = "BMI",
       y = "Waga") +
  scale_colour_gradient2(low = "blue", mid = "white", high = "red", midpoint = median(patients$Height)) +
  theme_minimal() +
  theme(panel.grid.minor = element_blank())

ggsave("wykres_punktowy.png", width = 16, height = 16, units = "cm")

