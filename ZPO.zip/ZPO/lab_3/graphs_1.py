# Aleksandra Ślęzak, 411686
from typing import List, Dict 

def adjmat_to_adjlist(adjmat: List[List[int]]) -> Dict[int, List[int]]:

    adjdict: Dict = {}
    row_i = 1
    for row in adjmat:
        entry_adjdict = []
        for (ver, edges) in enumerate(row, start=1):
            for i in range (0, edges):
                entry_adjdict.append(ver)
        if len(entry_adjdict):
            adjdict[row_i] = entry_adjdict
        row_i = row_i + 1
    return adjdict




def dfs_recursive(G: Dict[int, List[int]], s: int) -> List[int]:

    v = dfs_recur(G, s)
    return v

def dfs_recur(G: Dict[int, List[int]], s: int, v: List[int] = None) -> List[int]:
    
    if v is None:
        v = []
        v.append(s)

    if s not in v:
        v.append(s)
    
    for k in G[s]:
        if k not in v:
            dfs_recur(G, k, v)
    return v


 


def dfs_iterative(G: Dict[int, List[int]], s: int) -> List[int]:

    visited_id = []
    stos = [s]

    while stos:
        v = stos.pop(0)
        if v not in visited_id:
            visited_id.append(v)
            stos = [ u for u in G[v] if u not in visited_id] + stos
    return visited_id





def is_cycl(G: Dict[int, List[int]], s: int, visited: List[int] = None) -> bool:
    
    if visited is None:
        visited = []
    visited.append(s)
    
    if s not in G:
        return False

    for v in G[s]:
        if ((v in visited) and is_cycl(G, v, visited[:])):
            return True
    return False


def is_acyclic(G: Dict[int, List[int]]) -> bool:
    
    for v in range(1,len(G)):
        if is_cycl(G, v,None): 
            return False
    return True