//
// Created by pkleczek on 9/30/20.
//

#include "tsp_setup.hpp"

bool is_inf(cost_t val) { return val == INF; }
