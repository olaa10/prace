#include "TSP.hpp"

#include <algorithm>
#include <stack>
#include <optional>

std::vector<size_t> find_path1(std::vector<vertex_t> edges) {
    std::vector<size_t> path {edges[0].row, edges[0].col};
    edges.erase(edges.begin());

    while (!edges.empty()) {
        for(size_t i = 0; 1 < edges.size(); i++) {
            if (path.back() == edges[i].row) {
                path.push_back(edges[i].col);
                auto it = edges.begin();
                std::advance(it, i);
                edges.erase(it);
            }
            else if (path.front() == edges[i].col) {
                path.insert(path.begin(), edges[i].row);
                auto it = edges.begin();
                std::advance(it, i);
                edges.erase(it);
            }
        }
    }
    return path;
}

std::vector<size_t> find_path2(std::vector<vertex_t>& edges) {
    std::vector<size_t> path {edges[0].row, edges[0].col};
    edges.erase(edges.begin());

    while (!edges.empty()) {
        bool found = false;
        for(size_t i = 0; i < edges.size(); i++) {
            if (path.back() == edges[i].row) {
                path.push_back(edges[i].col);
                auto it = edges.begin();
                std::advance(it, i);
                edges.erase(it);
                found = true;
            }
            else if (path.front() == edges[i].col) {
                path.insert(path.begin(), edges[i].row);
                auto it = edges.begin();
                std::advance(it, i);
                edges.erase(it);
                found = true;
            }
        }
        if (!found) {
            return path;
        }
    }
    return path;
}

std::ostream& operator<<(std::ostream& os, const CostMatrix& cm) {
    for (std::size_t r = 0; r < cm.size(); ++r) {
        for (std::size_t c = 0; c < cm.size(); ++c) {
            const auto& elem = cm[r][c];
            os << (is_inf(elem) ? "INF" : std::to_string(elem)) << " ";
        }
        os << "\n";
    }
    os << std::endl;

    return os;
}

/* PART 1 */

/**
 * Create path from unsorted path and last 2x2 cost matrix.
 * @return The vector of consecutive vertex.
 */
path_t StageState::get_path() {
    reduce_cost_matrix();
    for(size_t row_idx = 0; row_idx < matrix_.size(); row_idx++) {
        for(size_t col_idx = 0; col_idx < matrix_[row_idx].size(); col_idx++) {
            if (matrix_[row_idx][col_idx] == 0) {
                append_to_path(vertex_t(row_idx, col_idx));
            }
        }
    }

    std::vector<size_t> path {unsorted_path_[0].row, unsorted_path_[0].col};
    while (path.back() != path.front()) {
        for(const auto& elem : unsorted_path_) {
            if (elem.row == path.back()) {
                path.push_back(elem.col);
            }
        }
    }
    path.erase(path.begin());
    return path;
}

/**
 * Get minimum values from each row and returns them.
 * @return Vector of minimum values in row.
 */
std::vector<cost_t> CostMatrix::get_min_values_in_rows() const {
    std::vector<cost_t> min_vals_in_rows;
    for (size_t i = 0; i < matrix_.size(); i++) {
        cost_t min_val = *std::min_element(matrix_[i].begin(), matrix_[i].end());
        if (is_inf(min_val)) {
            min_val = 0;
        }
        min_vals_in_rows.push_back(min_val);
    }
    return min_vals_in_rows;
}

/**
 * Reduce rows so that in each row at least one zero value is present.
 * @return Sum of values reduced in rows.
 */
cost_t CostMatrix::reduce_rows() {
    std::vector<cost_t> min_vals = get_min_values_in_rows();
    size_t row_idx = 0;
    for (auto& row : matrix_) {
        std::for_each(row.begin(), row.end(),
                      [&min_vals, row_idx](auto& elem) {
                        if (!is_inf(elem) && !is_inf(min_vals[row_idx])) {
                            elem = elem - min_vals[row_idx];
                        }
                    });
        row_idx++;
    }
    size_t sum = std::accumulate(min_vals.begin(), min_vals.end(), 0);
    return sum;
}

/**
 * Get minimum values from each column and returns them.
 * @return Vector of minimum values in columns.
 */
std::vector<cost_t> CostMatrix::get_min_values_in_cols() const {
    std::vector<cost_t> min_values;
    for(size_t col_idx = 0; col_idx < matrix_[0].size(); col_idx++) {
        cost_t min_val_for_col = std::numeric_limits<cost_t>::max();
        for (size_t row_idx = 0; row_idx <matrix_.size(); row_idx++) {
            if (min_val_for_col > matrix_[row_idx][col_idx]) {
                min_val_for_col = matrix_[row_idx][col_idx];
            }
        }
        if (is_inf(min_val_for_col)) {
            min_val_for_col = 0;
        }
        min_values.push_back(min_val_for_col);
    }
    return min_values;
}

/**
 * Reduces rows so that in each column at least one zero value is present.
 * @return Sum of values reduced in columns.
 */
cost_t CostMatrix::reduce_cols() {
    std::vector<cost_t> min_vals = get_min_values_in_cols();
    cost_t acc = 0;
    for(size_t col_idx = 0; col_idx < matrix_[0].size(); col_idx++) {
        acc += min_vals[col_idx];
        for(size_t row_idx = 0; row_idx < matrix_.size(); row_idx++) {
            if (!is_inf(matrix_[row_idx][col_idx])) {
                matrix_[row_idx][col_idx] -= min_vals[col_idx];
            }
        }
    }
    return acc;
}

/**
 * Get the cost of not visiting the vertex_t (@see: get_new_vertex())
 * @param row
 * @param col
 * @return The sum of minimal values in row and col, excluding the intersection value.
 */
cost_t CostMatrix::get_vertex_cost(std::size_t row, std::size_t col) const {
    cost_t min_row = INF;
    for(size_t col_idx = 0; col_idx < matrix_[row].size(); col_idx++) {
        if(col_idx != col && matrix_[row][col_idx] < min_row) {
            min_row = matrix_[row][col_idx];
        }
    }

    cost_t min_col = INF;
    for(size_t row_idx = 0; row_idx < matrix_.size(); row_idx++) {
        if(row_idx != row && matrix_[row_idx][col] < min_col) {
            min_col = matrix_[row_idx][col];
        }
    }

    return min_row + min_col;
}

/* PART 2 */

/**
 * Choose next vertex to visit:
 * - Look for vertex_t (pair row and column) with value 0 in the current cost matrix.
 * - Get the vertex_t cost (calls get_vertex_cost()).
 * - Choose the vertex_t with maximum cost and returns it.
 * @param cm
 * @return The coordinates of the next vertex.
 */
NewVertex StageState::choose_new_vertex() {
    NewVertex chosen_vertex;
    for(size_t row_idx = 0; row_idx < matrix_.size(); row_idx++) {
        for (size_t col_idx = 0; col_idx < matrix_[row_idx].size(); col_idx++) {
            if (matrix_[row_idx][col_idx] == 0) {
                cost_t vertex_cost = matrix_.get_vertex_cost(row_idx, col_idx);
                if (vertex_cost > chosen_vertex.cost) {
                    chosen_vertex.cost = vertex_cost;
                    chosen_vertex.coordinates.row = row_idx;
                    chosen_vertex.coordinates.col = col_idx;
                }
            }
        }
    }
    return chosen_vertex;
}

/**
 * Update the cost matrix with the new vertex.
 * @param new_vertex
 */
void StageState::update_cost_matrix(vertex_t new_vertex) {
    for(size_t row_idx = 0; row_idx < matrix_.size(); row_idx++) {
        matrix_[row_idx][new_vertex.col] = INF;
    }

    for(size_t col_idx = 0; col_idx < matrix_[new_vertex.row].size(); col_idx++) {
        matrix_[new_vertex.row][col_idx] = INF;
    }

    matrix_[new_vertex.col][new_vertex.row] = INF;

    std::vector<vertex_t> edges(unsorted_path_);

    std::vector<size_t> path = find_path1(edges);
    matrix_[path.back()][path[0]] = INF;

    while (!edges.empty()) {
        std::vector<size_t> path = find_path2(edges);
        matrix_[path.back()][path[0]] = INF;
    }
}

/**
 * Reduce the cost matrix.
 * @return The sum of reduced values.
 */
cost_t StageState::reduce_cost_matrix() {
    return matrix_.reduce_rows() + matrix_.reduce_cols();
}

/**
 * Given the optimal path, return the optimal cost.
 * @param optimal_path
 * @param m
 * @return Cost of the path.
 */
cost_t get_optimal_cost(const path_t& optimal_path, const cost_matrix_t& m) {
    cost_t cost = 0;

    for (std::size_t idx = 1; idx < optimal_path.size(); ++idx) {
        cost += m[optimal_path[idx - 1]][optimal_path[idx]];
    }

    // Add the cost of returning from the last city to the initial one.
    cost += m[optimal_path[optimal_path.size() - 1]][optimal_path[0]];

    return cost;
}

/**
 * Create the right branch matrix with the chosen vertex forbidden and the new lower bound.
 * @param m
 * @param v
 * @param lb
 * @return New branch.
 */
StageState create_right_branch_matrix(cost_matrix_t m, vertex_t v, cost_t lb) {
    CostMatrix cm(m);
    cm[v.row][v.col] = INF;
    return StageState(cm, {}, lb);
}

/**
 * Retain only optimal ones (from all possible ones).
 * @param solutions
 * @return Vector of optimal solutions.
 */
tsp_solutions_t filter_solutions(tsp_solutions_t solutions) {
    cost_t optimal_cost = INF;
    for (const auto& s : solutions) {
        optimal_cost = (s.lower_bound < optimal_cost) ? s.lower_bound : optimal_cost;
    }

    tsp_solutions_t optimal_solutions;
    std::copy_if(solutions.begin(), solutions.end(),
                 std::back_inserter(optimal_solutions),
                 [&optimal_cost](const tsp_solution_t& s) { return s.lower_bound == optimal_cost; }
    );

    return optimal_solutions;
}

/**
 * Solve the TSP.
 * @param cm The cost matrix.
 * @return A list of optimal solutions.
 */
tsp_solutions_t solve_tsp(const cost_matrix_t& cm) {

    StageState left_branch(cm);

    // The branch & bound tree.
    std::stack<StageState> tree_lifo;

    // The number of levels determines the number of steps before obtaining
    // a 2x2 matrix.
    std::size_t n_levels = cm.size() - 2;

    tree_lifo.push(left_branch);   // Use the first cost matrix as the root.

    cost_t best_lb = INF;
    tsp_solutions_t solutions;

    while (!tree_lifo.empty()) {

        left_branch = tree_lifo.top();
        tree_lifo.pop();

        while (left_branch.get_level() != n_levels && left_branch.get_lower_bound() <= best_lb) {
            // Repeat until a 2x2 matrix is obtained or the lower bound is too high...

            if (left_branch.get_level() == 0) {
                left_branch.reset_lower_bound();
            }

            // 1. Reduce the matrix in rows and columns.
            cost_t new_cost = left_branch.reduce_cost_matrix(); // @TODO (KROK 1)

            // 2. Update the lower bound and check the break condition.
            left_branch.update_lower_bound(new_cost);
            if (left_branch.get_lower_bound() > best_lb) {
                break;
            }

            // 3. Get new vertex and the cost of not choosing it.
            NewVertex new_vertex = left_branch.choose_new_vertex(); // @TODO (KROK 2)

            // 4. @TODO Update the path - use append_to_path method.
            left_branch.append_to_path(new_vertex.coordinates);

            // 5. @TODO (KROK 3) Update the cost matrix of the left branch.
            left_branch.update_cost_matrix(new_vertex.coordinates);

            // 6. Update the right branch and push it to the LIFO.
            cost_t new_lower_bound = left_branch.get_lower_bound() + new_vertex.cost;
            tree_lifo.push(create_right_branch_matrix(cm, new_vertex.coordinates,
                                                      new_lower_bound));
        }

        if (left_branch.get_lower_bound() <= best_lb) {
            // If the new solution is at least as good as the previous one,
            // save its lower bound and its path.
            best_lb = left_branch.get_lower_bound();
            path_t new_path = left_branch.get_path();
            solutions.push_back({get_optimal_cost(new_path, cm), new_path});
        }
    }

    return filter_solutions(solutions); // Filter solutions to find only optimal ones.
}

//Aleksandra Ślęzak, 411686