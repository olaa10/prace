import unittest
import graphs_2

class FindMinTrailTest(unittest.TestCase):
    def test_min_trail(self):
        graph = graphs_2.load_multigraph_from_file("data/directed_graph_blank_lines.dat")
        trail = graphs_2.find_min_trail(graph, 1, 3)
        self.assertEqual(sum([el.edge_weight for el in trail]), graphs_2.nx.dijkstra_path_length(graph, 1, 3))


if __name__ == '__main__':
    unittest.main()
