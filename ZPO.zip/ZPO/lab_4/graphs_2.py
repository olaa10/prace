#Aleksandra Ślęzak, 411686
from typing import List, Set, Dict
from typing import NamedTuple
import networkx as nx
 
# Pomocnicza definicja podpowiedzi typu reprezentującego etykietę
# wierzchołka (liczba 1..n).
VertexID = int
EdgeID = int

# Pomocnicza definicja podpowiedzi typu reprezentującego listę sąsiedztwa.
AdjList = Dict[VertexID, List[VertexID]]
 
Distance = int
 
def neighbors(adjlist: AdjList, start_vertex_id: VertexID = None, max_distance: Distance = 0) -> Set[VertexID]:
    
    if len(adjlist) < 0:
        return None

    if start_vertex_id is None:
        start_vertex_id=list(adjlist.keys())[0]    

    if start_vertex_id not in adjlist.keys():
        return None
    
    visited: Dict[VertexID, Distance] = {}
    kolejka=[(start_vertex_id, 0)]

    while kolejka:
        vertex, distance = kolejka.pop(0)

        if distance > max_distance:
            break

        if vertex not in visited.keys():
            visited[vertex] = distance

        if vertex in adjlist.keys():
            for n in adjlist[vertex]:
                if n not in visited:
                    kolejka.append((n,distance+1))

    return set([i for i in visited.keys() if max_distance >= visited[i] > 0])




 
# Nazwana krotka reprezentująca segment ścieżki.
class TrailSegmentEntry(NamedTuple):
    start_vertex_id: VertexID
    end_vertex_id: VertexID
    edge_id: EdgeID
    edge_weight: float
 
Trail = List[TrailSegmentEntry]
 
 
def load_multigraph_from_file(filepath: str) -> nx.MultiDiGraph:
    """Stwórz multigraf na podstawie danych o krawędziach wczytanych z pliku.
 
    :param filepath: względna ścieżka do pliku (wraz z rozszerzeniem)
    :return: multigraf
    """
    graph = []
    multigraph = nx.MultiDiGraph()
    with open(filepath) as file:
        if open(filepath):
            for line in file:
                if line.strip():
                    graph.append(tuple(map(float,line.split(' '))))

        else:
            return None
        
    multigraph.add_weighted_edges_from(graph)
    file.close()
    return multigraph
 
def find_min_trail(g: nx.MultiDiGraph, v_start: VertexID, v_end: VertexID) -> Trail:
    """Znajdź najkrótszą ścieżkę w grafie pomiędzy zadanymi wierzchołkami.
 
    :param g: graf
    :param v_start: wierzchołek początkowy
    :param v_end: wierzchołek końcowy
    :return: najkrótsza ścieżka
    """
    path = nx.dijkstra_path(g, v_start, v_end)
    trail: Trail = []

    for id, i in enumerate(path[:-1]):
        tab = [g[i][path[id+1]][k]['weight'] for k in g[i][path[id+1]]]
        idx = tab.index(min(tab))
        jump = TrailSegmentEntry(i, path[id+1], idx, g[i][path[id+1]][idx]['weight'])
        trail.append(jump)
    return trail
 
 
def trail_to_str(trail: Trail) -> str:
    """Wyznacz reprezentację tekstową ścieżki.
 
    :param trail: ścieżka
    :return: reprezentacja tekstowa ścieżki
    """
    if trail is None:
        return None

    suma = 0.0
    sum = "{k}".format(k=trail[0].start_vertex_id)
    for i in range(len(trail)):
        suma = suma + trail[i].edge_weight
        sum = sum + f" -[{trail[i].edge_id}: {trail[i].edge_weight}]-> {trail[i].end_vertex_id}"
    sum = sum + f'  (total = {suma})'
    return sum
