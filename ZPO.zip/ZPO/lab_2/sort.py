# Aleksandra Ślęzak, 411686

from typing import List

def quicksort_algorytm(I:List[int], start: int, stop: int) -> List[int]:
    
    i = start
    j = stop
    pivot = I[stop]

    while i < j:
        while I[i] < pivot:
            i = i + 1
        while I[j] > pivot:
            j = j - 1
 
        if i <= j:
            I[i], I[j] = I[j], I[i]
            i = i + 1
            j = j - 1
        
    if start < j:
        quicksort_algorytm(I, start, j)

    if i < stop:
        quicksort_algorytm(I, i, stop)

def quicksort(lista:List[int]) -> List[int]:
    
    start = 0
    I = list(lista)
    stop = len(I) - 1
    quicksort_algorytm(I, start, stop)
    return I

def bubblesort_algortym(I: List[int]) -> List[int]:

    n = len(I)
    ilosc_p = 0

    while n > 1:

        zamiana = False
        for i in range(1, n):
            ilosc_p = ilosc_p + 1

            if I[i - 1] > I[i]:
                I[i - 1], I[i] = I[i], I[i -1]
                zamiana = True
        
        if not zamiana:
            break
        n = n - 1 
    return ilosc_p

def bubblesort(lista: List[int]) -> List[int]:
    I = list(lista)
    ilosc_p = bubblesort_algortym(I)
    return I, ilosc_p
