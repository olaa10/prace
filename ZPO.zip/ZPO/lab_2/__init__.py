# Pozostaw ten plik pusty, ew. wykorzystaj do własnych testów.
